<?php
function brandonbirk_register_custom_post_types() {
    
    // Register Works CPT
    $labels = array(
        'name'               => _x( 'Works', 'post type general name'  ),
        'singular_name'      => _x( 'Works', 'post type singular name'  ),
        'menu_name'          => _x( 'Works', 'admin menu'  ),
        'name_admin_bar'     => _x( 'Works', 'add new on admin bar' ),
        'add_new'            => _x( 'Add New', 'work' ),
        'add_new_item'       => __( 'Add New Work' ),
        'new_item'           => __( 'New Work' ),
        'edit_item'          => __( 'Edit Work' ),
        'view_item'          => __( 'View Work'  ),
        'all_items'          => __( 'All Work Posts' ),
        'search_items'       => __( 'Search Work Posts' ),
        'parent_item_colon'  => __( 'Parent Work Posts:' ),
        'not_found'          => __( 'No work posts found.' ),
        'not_found_in_trash' => __( 'No work posts found in Trash.' ),
    );
    
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'show_in_rest'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'work-posts' ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 7,
        'menu_icon'          => 'dashicons-admin-customizer',
        'template'           => array( array( 'core/quote' ) ),
    );
    
    register_post_type( 'brandonbirk-works', $args );

}
    
add_action( 'init', 'brandonbirk_register_custom_post_types' );

    function brandonbirk_register_taxonomies() {
        // Add Work Category taxonomy
        $labels = array(
            'name'              => _x( 'Work Categories', 'taxonomy general name' ),
            'singular_name'     => _x( 'Work Category', 'taxonomy singular name' ),
            'search_items'      => __( 'Search Work Categories' ),
            'all_items'         => __( 'All Work Category' ),
            'parent_item'       => __( 'Parent Work Category' ),
            'parent_item_colon' => __( 'Parent Work Category:' ),
            'edit_item'         => __( 'Edit Work Category' ),
            'view_item'         => __( 'View Work Category' ),
            'update_item'       => __( 'Update Work Category' ),
            'add_new_item'      => __( 'Add New Work Category' ),
            'new_item_name'     => __( 'New Work Category Name' ),
            'menu_name'         => __( 'Work Category' ),
        );
        $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_in_menu'      => true,
            'show_in_nav_menu'  => true,
            'show_in_rest'      => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'works-categories' ),
        );
        register_taxonomy( 'brandonbirk-works-category', array( 'brandonbirk-works' ), $args );

    }
    
    add_action( 'init', 'brandonbirk_register_taxonomies');


// This flushes the permalinks if the theme is changed
function fwd_rewrite_flush() {
    fwd_register_custom_post_types();
    fwd_register_taxonomies();
    flush_rewrite_rules();
}

add_action( 'after_switch_theme', 'fwd_rewrite_flush' );