<?php
/**
 * The template for displaying Works Post types
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Brandon_Birk_Theme
 */

get_header();
?>

	<main id="primary" class="site-main">

		<!-- /** Display the blog posts with only excerpts */ -->
		<?php
		
		while ( have_posts() ) :
			the_post();
			
			$args = array( 
				'post_type'      => 'brandonbirk-works',
				'posts_per_page'	=> -1,
				'order'				=> 'ASC',
				'orderby'			=> 'title',
			);
			
			$blog_query = new WP_Query( $args );
			
			if ( $blog_query -> have_posts() ) {
				while ( $blog_query -> have_posts() ) {
					$blog_query -> the_post();
					?>
					<article class='each-work'>
					<a href="<?php the_permalink(); ?>">
							<h3><?php the_title(); ?></h3>
					</a>

							<p><?php the_excerpt(); ?></p>
					<?php

					// Display the taxonomy the student belongs to
					$taxonomy = 'brandonbirk-works-category';

					$term_list = wp_get_post_terms($post->ID, $taxonomy, $args);
	
					foreach($term_list as $term_single) {
						echo '<p>Specialty: ' . $term_single->name . '</p>';
					}
					?>
				</article>
					<?php
			}

				wp_reset_postdata();
			}

		endwhile;[];
		?>


	</main><!-- #main -->

<?php
get_sidebar();
get_footer();
