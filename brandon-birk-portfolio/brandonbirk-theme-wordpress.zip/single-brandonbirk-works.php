<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Brandon_Birk_Theme
 */

get_header();
?>

	<main id="primary" class="site-main">

		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', get_post_type() );
			
			?>

			<div class="works-container">
			<?php
					
					// Output all of the ACF Fields, if filled
					if ( function_exists( 'get_field' ) ) {
						if ( get_field( 'title') ) {
							the_field('title');
						}
					}
					
					if ( function_exists( 'get_field' ) ) {
						if ( get_field( 'cover') ) {
							$image1=get_field( 'cover');
							echo '<img src="' . esc_url($image1['url']) . '" alt="' . esc_attr($image1['alt']) . '">';
						}
					}

					if ( function_exists( 'get_field' ) ) {
						if ( get_field( 'content_description_1') ) {
							the_field('content_description_1');
						}
					}

					if ( function_exists( 'get_field' ) ) {
						if ( get_field( 'content_description_2') ) {
							the_field('content_description_2');
						}
					}

					if ( function_exists( 'get_field' ) ) {
						if ( get_field( 'image_2') ) {
							echo '<img src="' . esc_url(get_field( 'image_2')['url']) . '" alt="' . esc_attr(get_field( 'image_2')['alt']) . '">';
						}
					}

					if ( function_exists( 'get_field' ) ) {
						if ( get_field( 'content_description_3') ) {
							the_field('content_description_3');
						}
					}
			
				?>

			</div>

			<?php

		endwhile; // End of the loop.
		?>

	</main><!-- #main -->

<?php
get_sidebar();
get_footer();
